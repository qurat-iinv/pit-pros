import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const CustomAccordion = () => {
  return (
    <View>
      <Text>CustomAccordion</Text>
    </View>
  );
};

export default CustomAccordion;

const styles = StyleSheet.create({});
