export let dropdownData = [
  {id: 1, label: '01 - Light Duty Vehicle (up to 1 Ton) (Default)'},
  {id: 2, label: '02 - Light Duty Vehicle (up to 2 Ton)'},
  {id: 3, label: '03 - Light Duty Vehicle (up to 3 Ton)'},
  {id: 4, label: '04 - Light Duty Vehicle (up to 4 Ton)'},
  {id: 5, label: '05 - Light Duty Vehicle (up to 5 Ton)'},
];
