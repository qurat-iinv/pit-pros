import React, {useState} from 'react';
import {StyleSheet, Text, View} from 'react-native';
import sizer from '../../helpers/sizer';
import Icon from 'react-native-vector-icons/FontAwesome6';

const Stepper = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [completed, setCompleted] = useState(false);

  const steps = [
    'Request Details',
    'Services And Products',
    'Schedulse',
    'Authorize',
  ];

  // const handleIncreaseStep = () => {
  //   setActiveStep(prev => prev + 1);
  // };
  // console.log(activeStep);

  const Line = ({bgColor = '#C7C7C7'}) => {
    return <View style={[styles.line, {backgroundColor: bgColor}]}></View>;
  };

  return (
    <View style={styles.container}>
      {steps.map((stepTitle, currentIndex) => {
        const inProgress = activeStep === currentIndex;
        const isDone = activeStep > currentIndex;
        const inComplete = !inProgress && !isDone;
        const isLastStep = currentIndex === steps.length - 1;

        return (
          <View key={currentIndex} style={styles.stepContainer}>
            <View
              style={{
                width: 30,
                height: 30,
                borderWidth: 3,
                justifyContent: 'center',
                alignItems: 'center',
                borderRadius: 100,
                padding: 2,
              }}>
              <View
                onStartShouldSetResponder={() => setActiveStep(currentIndex)}
                style={
                  inProgress
                    ? [styles.stepperContainer, {borderColor: '#DC0028'}]
                    : inComplete
                    ? [styles.stepperContainer, {borderColor: '#C7C7C7'}]
                    : isDone
                    ? [styles.filled, {width: 30, height: 30}]
                    : null
                }>
                {inProgress && <View style={styles.filled}></View>}
                {isDone ? <Icon name="check" size={18} color="white" /> : null}
              </View>
            </View>

            <View
              style={{
                width: isLastStep ? 0 : sizer.moderateScale(58),
                height: 2,
                position: 'absolute',
                left: isLastStep ? 0 : 39,
                backgroundColor: isDone ? '#DC0028' : '#C7C7C7',
              }}></View>
            <View
              style={{
                position: 'absolute',
                bottom: -35,
                height: 40,
                width: 62,
                justifyContent: 'center',
              }}>
              <Text
                style={{
                  fontSize: 9,
                  textAlign: 'center',
                  // backgroundColor: 'pink',
                  color: inProgress
                    ? '#DC0028'
                    : inComplete
                    ? '#C7C7C7'
                    : isDone
                    ? 'black'
                    : null,
                }}>
                {stepTitle}
              </Text>
            </View>
          </View>
        );
      })}
    </View>
  );
};

export default Stepper;

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 15,
    // backgroundColor: 'yellow',
  },

  stepContainer: {
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
    // width: 45,
    // paddingLeft: 5,
    // paddingRight: 5,
    // backgroundColor: "blue"
  },

  stepperContainer: {
    width: 30,
    height: 30,
    borderWidth: 3,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 100,
    padding: 2,
  },

  filled: {
    width: 20,
    height: 20,
    backgroundColor: '#DC0028',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 50,
  },

  line: {
    width: sizer.moderateScale(60),
    height: 2,
    position: 'absolute',
    left: 30,
  },
});

// {
//   steps.map((stepTitle, currentIndex) => {
//     const inProgress = activeStep === currentIndex;
//     const isDone = activeStep > currentIndex;
//     const inComplete = !inProgress && !isDone;
//     const isLastStep = currentIndex === steps.length - 1;
//     return (
//       <View key={currentIndex}>
//         <View
//           onStartShouldSetResponder={() => setActiveStep(currentIndex)}
//           style={
//             inProgress
//               ? [styles.stepperContainer, {borderColor: '#DC0028'}]
//               : inComplete
//               ? [styles.stepperContainer, {borderColor: '#C7C7C7'}]
//               : isDone
//               ? [styles.filled, {width: 30, height: 30}]
//               : null
//           }>
//           {/* {!isLastStep && <Line />} */}

//           <View
//             style={{
//               width: isLastStep ? 0 : sizer.moderateScale(60),
//               height: 2,
//               position: 'absolute',
//               left: isLastStep ? 0 : 33,
//               backgroundColor: '#DC0028',
//             }}></View>
//           {/* {isDone && <Line bgColor="#DC0028" />} */}
//           {inProgress && <View style={styles.filled}></View>}
//         </View>
//         <View style={{marginTop: 10}}>
//           <Text
//             style={{
//               fontSize: 10,
//               width: 60,
//               position: 'absolute',
//               textAlign: 'center',
//               alignItems: 'center',
//               // backgroundColor: 'pink',
//               color: inProgress
//                 ? '#DC0028'
//                 : inComplete
//                 ? '#C7C7C7'
//                 : isDone
//                 ? 'black'
//                 : null,
//             }}>
//             {stepTitle}
//           </Text>
//         </View>
//       </View>
//     );
//   });
// }
