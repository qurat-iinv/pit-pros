import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

import Header from '../../components/custom-headers/header';
import Card from '../../components/ui-card/card';
import {Container} from '../../atom-components';
import Stepper from '../../components/stepper/stepper';

const Services = () => {
  return (
    <Container>
      <Header title="New Service Order" titleCenter />
      <View style={styles.cardContainer}>
        <Card title="Services" badgeNumber={2} dollars={6} />
        <Card title="Products" badgeNumber={2} dollars={6} />
        <Card title="Total" dollars={12} />
      </View>

      <View>
        <Stepper />
      </View>
    </Container>
  );
};

export default Services;

const styles = StyleSheet.create({
  heading: {
    fontSize: 14,
    fontWeight: '800',
    color: 'black',
  },

  cardContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 18,
  },
});
