export const historyData = [
  {
    date: 'Sunday 15 May 2023',
    time: '9:30 AM To 2:00 PM',
    status: 'Completed',
    workHours: '8 Hours, 10 Minutes',
  },
  {
    date: 'Monday 16 May 2023',
    time: '1:30 AM To 5:00 PM',
    status: '',
    workHours: '10 Hours, 5 Minutes',
  },
  {
    date: 'Tuesday 17 May 2022',
    time: '1:00 PM To 2:00 PM',
    status: '',
    workHours: '5 Hours, 30 Minutes',
  },
  {
    date: 'Sunday 15 May 2023',
    time: '9:30 AM To 2:00 PM',
    status: 'Completed',
    workHours: '8 Hours, 10 Minutes',
  },
];
