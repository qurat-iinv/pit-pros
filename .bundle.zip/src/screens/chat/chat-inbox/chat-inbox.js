import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const ChatInbox = () => {
  return (
    <View>
      <Text>ChatInbox</Text>
    </View>
  );
};

export default ChatInbox;

const styles = StyleSheet.create({});
