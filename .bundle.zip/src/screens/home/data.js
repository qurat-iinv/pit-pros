export const appointmentCardData = [
  {
    title: 'Black Marvin',
    carModal: '2015 Ford Expedition',
    dateAndTime: 'Aug 18 · 9:30AM',
  },
  {
    title: 'Flores Juanita',
    carModal: 'Honda Civic Hatchback',
    dateAndTime: 'Sep 27 · 2:45PM',
  },
  {
    title: 'Cooper Kristin',
    carModal: 'Mercedes-Benz',
    dateAndTime: 'Sep 7 · 3:45PM',
  },
];
